<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'О нас',
);
?>
<h1>О нас</h1>

<p>Тут типо о нас
    
by updating the file <code><?php echo __FILE__; ?></code>.</p>
